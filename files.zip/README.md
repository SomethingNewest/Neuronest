# 🧠 NeuroNest — Brain Health for Every Stage of Life

A compassionate, interactive brain health education website focused on neurological disease prevention, cognitive training, and caregiver support for older adults.

---

## 📁 File Structure (Exact Names Required)

```
neuronest/                    ← Your GitHub repository root
│
├── index.html                ← Homepage (MUST be named exactly this for GitHub Pages)
├── README.md                 ← This file
│
├── css/
│   └── main.css              ← All styles (single stylesheet)
│
├── js/
│   └── main.js               ← All JavaScript logic
│
└── pages/
    ├── learn.html            ← Curriculum: 5 neurological conditions
    ├── games.html            ← Brain Games Arcade (5 games)
    ├── journal.html          ← Daily brain journal + streak tracker
    ├── caregiver.html        ← Caregiver Corner resources
    └── chat.html             ← Ask NeuroNest AI chatbot
```

> ⚠️ **Critical:** `index.html` must be in the **root** of the repository. GitHub Pages serves from this file automatically.

---

## 🚀 Deploying to GitHub Pages (Step-by-Step)

### Step 1 — Create a GitHub Account
If you don't have one, go to [github.com](https://github.com) and sign up. It's free.

### Step 2 — Create a New Repository
1. Click the **"+"** icon in the top right → **"New repository"**
2. Name it exactly: `neuronest` (all lowercase, no spaces)
3. Set visibility to **Public**
4. Do **NOT** check "Add a README" (we have our own)
5. Click **"Create repository"**

### Step 3 — Upload Your Files
**Option A — Using GitHub's web interface (easiest):**
1. On your new empty repository page, click **"uploading an existing file"**
2. Drag and drop ALL files and folders from your `neuronest/` folder
3. Make sure the folder structure is preserved:
   - `index.html` at the root level
   - `css/main.css` in a `css` folder
   - `js/main.js` in a `js` folder
   - All 5 `.html` files inside a `pages` folder
4. Scroll down, write a commit message like `"Initial upload"`, click **"Commit changes"**

**Option B — Using Git on your computer:**
```bash
cd /path/to/neuronest
git init
git add .
git commit -m "Initial NeuroNest upload"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/neuronest.git
git push -u origin main
```

### Step 4 — Enable GitHub Pages
1. In your repository, click the **"Settings"** tab (gear icon)
2. Scroll down to the **"Pages"** section in the left sidebar
3. Under **"Source"**, select **"Deploy from a branch"**
4. Under **"Branch"**, select **"main"** and **"/ (root)"**
5. Click **Save**

### Step 5 — Get Your Live URL
After 1–3 minutes, your site will be live at:
```
https://YOUR_USERNAME.github.io/neuronest/
```

You'll see a green checkmark in the Pages section when it's ready.

---

## ✨ Features

| Feature | Description |
|--------|-------------|
| 📚 **Learn** | Plain-English curriculum on Alzheimer's, Parkinson's, Dementia, Stroke, and MCI |
| 🎮 **Brain Games Arcade** | 5 clinically-inspired games: Memory Match, Word Recall, Pattern Memory, Word Scramble, Number Span |
| 📓 **My Journal** | Daily mood + sharpness check-in with streak tracking, stored locally in the browser |
| 🤝 **Caregiver Corner** | Communication tips, red flags, legal planning, self-care, and stage guides |
| 💬 **Ask NeuroNest** | AI chatbot powered by Claude for brain health Q&A |
| ✨ **Daily Brain Boost** | 30 rotating daily brain tips — one per day, all year |

---

## 🎮 Brain Games & What They Train

| Game | Cognitive Domain |
|------|-----------------|
| Memory Match | Visual short-term memory |
| Word Recall | Episodic memory |
| Pattern Memory | Working memory & attention |
| Word Scramble | Language & semantic memory |
| Number Span | Working memory capacity |

---

## 🤖 AI Chatbot Setup

The **Ask NeuroNest** page uses the Anthropic Claude API. 

For a public GitHub Pages site, the API call is made directly from the browser. To use this feature:

1. The API key is handled server-side in the Claude.ai environment where this was built
2. For your own deployment, you'll need to either:
   - Add your own Anthropic API key to `js/main.js` (not recommended for public sites)
   - Set up a simple backend proxy (Netlify Functions or Vercel Functions work well)
   - Alternatively, the chat page works gracefully without the API key — it simply shows an error message if the API is unavailable

---

## 💾 Data Storage

- All journal entries, streaks, and game scores are stored in **localStorage** (the user's own browser)
- No data is sent to any server (except AI chat queries to Anthropic's API)
- This means data is private and stays on the user's device

---

## 🎨 Design Notes

- **Fonts:** Fraunces (display/headings) + DM Sans (body)
- **Color Palette:** Forest green (#1C3A2F), Sage (#4A7C63), Gold (#C8913A), Cream (#FAF7F2)
- **Design philosophy:** Warm, readable, accessible — built for older adults with generous font sizes and high contrast

---

## ♿ Accessibility Features

- Large, readable font sizes (base 18px)
- High contrast color ratios throughout
- Mobile-responsive layout
- Keyboard-navigable forms
- Touch-friendly button sizes

---

## 📝 How to Update Content

- **Add a new condition:** Copy a `<div class="condition-section">` block in `pages/learn.html` and add a matching tab button
- **Add a brain game:** Add a new panel in `pages/games.html` and add a tab button
- **Update Daily Tips:** Edit the `brainBoosts` array in `js/main.js`
- **Update colors:** Change CSS variables at the top of `css/main.css`

---

## ⚠️ Disclaimer

NeuroNest is an educational resource and passion project. It is **not** a medical tool and does not provide medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional for personal medical concerns.

---

*Built with 💚 as a passion project for brain health education.*
